import SwiftUI

// MARK: - RoomsView (Pack 6: вкладка "Запросы" влезает в одну строку)
// Баг: "Запросы" отображалось как "Запрос Ы" — не помещалось
// Фикс: использовать shorter labels + .lineLimit(1) + .minimumScaleFactor

struct RoomsView: View {
    @EnvironmentObject private var tabRouter: TabRouter
    @State private var selectedTab: Tab = .myRooms
    
    enum Tab: String, CaseIterable, Identifiable {
        case myRooms = "Мои"
        case join = "Войти"
        case requests = "Запросы"
        
        var id: String { rawValue }
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Pack 6: Compact segmented control
                Picker("", selection: $selectedTab) {
                    ForEach(Tab.allCases) { tab in
                        Text(tab.rawValue)
                            .lineLimit(1)           // ← Pack 6: запрет переноса
                            .minimumScaleFactor(0.7) // ← Pack 6: ужимается если не влезает
                            .tag(tab)
                    }
                }
                .pickerStyle(.segmented)
                .padding()
                
                switch selectedTab {
                case .myRooms:
                    MyRoomsList()
                case .join:
                    JoinRoomView(onRoomJoined: { _ in })
                case .requests:
                    Color.clear.overlay(Text("Нет запросов").foregroundStyle(.secondary))
                }
            }
            .background(Color.plinkBgGradient)
            .navigationTitle("Комнаты")
            .onReceive(tabRouter.$roomsSubTab) { subTab in
                // Pack 6: когда из Home нажимают "Присоединиться" — переключиться на .join
                if let tab = Tab(rawValue: subTab.rawValue) {
                    withAnimation { selectedTab = tab }
                }
            }
        }
    }
}

// MARK: - Stubs

private struct MyRoomsList: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                ForEach(0..<2) { _ in
                    RoomCardView(room: .preview)
                }
            }
            .padding()
        }
    }
}

#Preview {
    RoomsView()
        .environmentObject(TabRouter.shared)
}
