import SwiftUI
import AVFoundation

// MARK: - AnimatedGradientBackground (Pack 6: быстрее + multi-color)
/// Анимированный градиентный фон с 3-цветной палитрой (Purple → Pink → Orange).
/// Pack 6: ускорена анимация в 3x, добавлены 3 цвета.

struct AnimatedGradientBackground: View {
    @State private var animateGradient = false
    
    // Pack 6: в 3 раза быстрее (было 8 сек, стало 3 сек)
    private let animationDuration: Double = 3.0
    
    var body: some View {
        LinearGradient(
            colors: [
                Color(red: 0.067, green: 0.051, blue: 0.157),    // тёмный пурпур
                Color(red: 0.157, green: 0.051, blue: 0.118),    // тёмный розовый
                Color(red: 0.118, green: 0.051, blue: 0.078),    // тёмный оранжевый
                Color(red: 0.051, green: 0.078, blue: 0.118),    // тёмный cyan
            ],
            startPoint: animateGradient ? .topLeading : .bottomTrailing,
            endPoint: animateGradient ? .bottomTrailing : .topLeading
        )
        .ignoresSafeArea()
        .animation(
            .easeInOut(duration: animationDuration)
                .repeatForever(autoreverses: true),
            value: animateGradient
        )
        .onAppear {
            animateGradient = true
        }
    }
}

// MARK: - Preview

#Preview("Animated Gradient") {
    AnimatedGradientBackground()
        .overlay {
            VStack {
                Text("Plink")
                    .font(.largeTitle.bold())
                    .foregroundStyle(.white)
                Text("Multi-color background")
                    .foregroundStyle(.white.opacity(0.7))
            }
        }
}

#Preview("Bioluminescent") {
    BioluminescentBackground()
        .overlay {
            VStack {
                Text("Plink")
                    .font(.largeTitle.bold())
                    .foregroundStyle(.white)
                Text("3-color blobs")
                    .foregroundStyle(.white.opacity(0.7))
            }
        }
}
