import SwiftUI
import AVFoundation

// MARK: - SubtitlesManager (Pack 5: Multi-language subtitles + audio tracks)
/// Управление субтитрами и аудиодорожками для AVPlayer

@MainActor
final class SubtitlesManager: ObservableObject {
    static let shared = SubtitlesManager()
    
    @Published private(set) var availableSubtitles: [SubtitleTrack] = []
    @Published private(set) var availableAudioTracks: [AudioTrack] = []
    @Published private(set) var selectedSubtitle: SubtitleTrack?
    @Published private(set) var selectedAudioTrack: AudioTrack?
    
    private var player: AVPlayer?
    private var legibleObserver: NSKeyValueObservation?
    
    private init() {}
    
    // MARK: - Setup
    
    func setup(player: AVPlayer) {
        self.player = player
        loadAvailableTracks()
        observeTrackChanges()
    }
    
    // MARK: - Load Tracks
    
    func loadAvailableTracks() {
        guard let currentItem = player?.currentItem else { return }
        
        // Subtitles / closed captions
        let legibleGroups = currentItem.asset.mediaSelectionGroup(forMediaCharacteristic: .legible)
        var subtitles: [SubtitleTrack] = []
        
        if let group = legibleGroups {
            for (index, option) in group.options.enumerated() {
                let track = SubtitleTrack(
                    id: option.locale?.identifier ?? "track_\(index)",
                    name: option.displayName,
                    languageCode: option.locale?.identifier,
                    isDefault: option == group.defaultOption
                )
                subtitles.append(track)
            }
        }
        // Add "Off" option
        subtitles.insert(SubtitleTrack(id: "off", name: "Off", languageCode: nil, isDefault: false), at: 0)
        
        availableSubtitles = subtitles
        selectedSubtitle = subtitles.first(where: { $0.isDefault }) ?? subtitles.first
        
        // Audio tracks
        let audibleGroups = currentItem.asset.mediaSelectionGroup(forMediaCharacteristic: .audible)
        var audioTracks: [AudioTrack] = []

        if let group = audibleGroups {
            for (index, option) in group.options.enumerated() {
                let track = AudioTrack(
                    id: option.locale?.identifier ?? "audio_\(index)",
                    name: option.displayName,
                    languageCode: option.locale?.identifier,
                    isDefault: option == group.defaultOption
                )
                audioTracks.append(track)
            }
        }
        availableAudioTracks = audioTracks
        selectedAudioTrack = audioTracks.first(where: { $0.isDefault }) ?? audioTracks.first
    }

    // MARK: - Select Track

    func selectSubtitle(_ track: SubtitleTrack) {
        guard let player, let currentItem = player.currentItem else { return }
        selectedSubtitle = track

        if track.id == "off" {
            if let group = currentItem.asset.mediaSelectionGroup(forMediaCharacteristic: .legible) {
                currentItem.select(nil, in: group)
            }
        } else {
            if let group = currentItem.asset.mediaSelectionGroup(forMediaCharacteristic: .legible),
               let option = group.options.first(where: { ($0.locale?.identifier ?? "") == track.id }) {
                currentItem.select(option, in: group)
            }
        }

        HapticManager.shared.tap()
    }

    func selectAudioTrack(_ track: AudioTrack) {
        guard let player, let currentItem = player.currentItem else { return }
        selectedAudioTrack = track

        if let group = currentItem.asset.mediaSelectionGroup(forMediaCharacteristic: .audible),
           let option = group.options.first(where: { ($0.locale?.identifier ?? "") == track.id }) {
            currentItem.select(option, in: group)
        }

        HapticManager.shared.tap()
    }

    // MARK: - Observers

    private func observeTrackChanges() {
        // 🔧 FIX: AVPlayer has no `currentLegibleOutput` KVO property.
        // Track selection updates are reflected via loadAvailableTracks() on demand.
        // No-op here; UI calls loadAvailableTracks() when displayed.
    }
    
    deinit {
        legibleObserver?.invalidate()
    }
}

// MARK: - Models

struct SubtitleTrack: Identifiable, Hashable {
    let id: String
    let name: String
    let languageCode: String?
    let isDefault: Bool
    
    var flag: String? {
        guard let code = languageCode else { return nil }
        // Convert language code to flag emoji
        // en → 🇬🇧, ru → 🇷🇺, etc.
        switch code.split(separator: "_").first.map(String.init) {
        case "en": return "🇬🇧"
        case "ru": return "🇷🇺"
        case "es": return "🇪🇸"
        case "de": return "🇩🇪"
        case "fr": return "🇫🇷"
        case "it": return "🇮🇹"
        case "ja": return "🇯🇵"
        case "ko": return "🇰🇷"
        case "zh": return "🇨🇳"
        case "ar": return "🇸🇦"
        case "hi": return "🇮🇳"
        case "pt": return "🇵🇹"
        case "tr": return "🇹🇷"
        default: return "🌐"
        }
    }
}

struct AudioTrack: Identifiable, Hashable {
    let id: String
    let name: String
    let languageCode: String?
    let isDefault: Bool
    
    var flag: String? {
        SubtitleTrack(id: id, name: name, languageCode: languageCode, isDefault: isDefault).flag
    }
}
