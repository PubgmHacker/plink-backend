// ФИКС ДЛЯ БЭКЕНДА: скопируйте этот файл в plink-backend/src/routes/rooms.ts
// и запушьте на GitHub. Railway автоматически передеплоит.
//
// Проблема: JWT содержит только {id}, без username → hostName = undefined → Prisma error
// Фикс: берём hostName из body как fallback
//
// Команда:
//   cd ~/Desktop/plink-backend
//   cp /path/to/backend-rooms-fix.ts src/routes/rooms.ts
//   git add src/routes/rooms.ts
//   git commit -m "Fix: hostName fallback from body when JWT lacks username"
//   git push

import { hashRoomPassword, verifyRoomPassword, requireHost } from '../middleware/security.js';

export default async function roomRoutes(fastify, _options) {
    const { prisma } = fastify;

    fastify.post('/rooms', {
        preHandler: [fastify.authenticate]
    }, async (request, reply) => {
        const { name, maxParticipants, mediaItem, privacy, password, hostName } = request.body;

        const hashedPassword = password 
            ? await hashRoomPassword(password) 
            : null;

        const room = await prisma.room.create({
            data: {
                name,
                hostID: request.user.id,
                hostName: request.user.username || hostName || 'Unknown',
                code: generateRoomCode(),
                maxParticipants: maxParticipants || 10,
                mediaItem: mediaItem ? JSON.stringify(mediaItem) : null,
                privacy: privacy || 'public',
                password: hashedPassword,
                hostIsPremium: await getUserPremiumStatus(prisma, request.user.id),
                isActive: true,
            }
        });

        const { password: _, ...roomWithoutPassword } = room;
        reply.send(roomWithoutPassword);
    });

    fastify.post('/rooms/join', {
        preHandler: [fastify.authenticate]
    }, async (request, reply) => {
        const { code, password } = request.body;
        const room = await prisma.room.findFirst({
            where: { code: code.toUpperCase(), isActive: true }
        });
        if (!room) return reply.status(404).send({ error: 'Комната не найдена' });
        if (room.password) {
            if (!password) return reply.status(401).send({ error: 'Требуется пароль' });
            const isValid = await verifyRoomPassword(password, room.password);
            if (!isValid) return reply.status(401).send({ error: 'Неверный пароль' });
        }
        const participantCount = await prisma.roomParticipant.count({
            where: { roomID: room.id }
        });
        if (participantCount >= room.maxParticipants) {
            return reply.status(409).send({ error: 'Комната заполнена' });
        }
        await prisma.roomParticipant.create({
            data: { roomID: room.id, userID: request.user.id }
        });
        const { password: _, ...roomWithoutPassword } = room;
        reply.send(roomWithoutPassword);
    });

    fastify.post('/rooms/:id/playback', {
        preHandler: [fastify.authenticate, requireHost(prisma)]
    }, async (request, reply) => {
        const { id } = request.params;
        const { time, isPlaying } = request.body;
        await prisma.playbackState.upsert({
            where: { roomID: id },
            update: { currentTime: time, isPlaying },
            create: { roomID: id, currentTime: time, isPlaying },
        });
        reply.send({ success: true });
    });

    fastify.get('/rooms', {
        preHandler: [fastify.authenticate]
    }, async (request, reply) => {
        const rooms = await prisma.room.findMany({
            where: { isActive: true, privacy: 'public' },
            include: { _count: { select: { participants: true } } },
            orderBy: { createdAt: 'desc' },
            take: 50,
        });
        const safeRooms = rooms.map(({ password, ...r }) => r);
        reply.send(safeRooms);
    });

    fastify.get('/rooms/mine', {
        preHandler: [fastify.authenticate]
    }, async (request, reply) => {
        const rooms = await prisma.room.findMany({
            where: {
                OR: [
                    { hostID: request.user.id },
                    { participants: { some: { userID: request.user.id } } }
                ]
            },
            include: { _count: { select: { participants: true } } },
            orderBy: { createdAt: 'desc' },
        });
        const safeRooms = rooms.map(({ password, ...r }) => r);
        reply.send(safeRooms);
    });
}

function generateRoomCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    return Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}

async function getUserPremiumStatus(prisma, userId) {
    const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { isPremium: true }
    });
    return user?.isPremium ?? false;
}
